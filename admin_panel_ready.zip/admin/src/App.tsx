import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { ProductProvider } from '../../src/context/ProductContext';
import { AdminProvider } from '../../src/context/AdminContext';
import AdminDashboard from './components/AdminDashboard';

function App() {
  return (
    <Router>
      <ProductProvider>
        <AdminProvider>
          <AdminDashboard />
        </AdminProvider>
      </ProductProvider>
    </Router>
  );
}

export default App;