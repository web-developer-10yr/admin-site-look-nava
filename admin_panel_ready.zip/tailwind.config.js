/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        'primary': {
          50: '#f3e7ff',
          100: '#e5cfff',
          200: '#d2afff',
          300: '#b988ff',
          400: '#a369fc',
          500: '#9061F9',
          600: '#7e48e9',
          700: '#6c38cd',
          800: '#5a2fa6',
          900: '#4c2982',
        },
        'secondary': {
          50: '#e3f8ff',
          100: '#c3edff',
          200: '#9ad6ff',
          300: '#6abcff',
          400: '#46a4fc',
          500: '#3994f5',
          600: '#277be0',
          700: '#1e61c2',
          800: '#1b4d9e',
          900: '#1a407f',
        },
        'accent': {
          50: '#fff6e5',
          100: '#ffeac3',
          200: '#ffd789',
          300: '#ffbf48',
          400: '#ffab24',
          500: '#ff9800',
          600: '#e67e00',
          700: '#b85c00',
          800: '#964b00',
          900: '#7a3f00',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.8s ease-out forwards',
        'slide-up': 'slideUp 0.5s ease-out forwards',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { transform: 'translateY(100%)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
      transitionProperty: {
        'height': 'height',
        'spacing': 'margin, padding',
      },
      boxShadow: {
        'soft': '0 4px 20px rgba(0, 0, 0, 0.08)',
      },
    },
  },
  plugins: [],
};