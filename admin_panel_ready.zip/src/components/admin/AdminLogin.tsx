import React, { useState } from 'react';
import { useAdmin } from '../../context/AdminContext';
import Button from '../ui/Button';
import { Lock } from 'lucide-react';

const AdminLogin: React.FC = () => {
  const { login } = useAdmin();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    
    // Simulate a slight delay for UX
    setTimeout(() => {
      const isSuccess = login(password);
      
      if (!isSuccess) {
        setError('Invalid password. Please try again.');
      }
      
      setIsLoading(false);
    }, 800);
  };

  return (
    <div className="max-w-md mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
      <div className="p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-16 w-16 bg-purple-100 dark:bg-purple-900 rounded-full mb-4">
            <Lock className="h-8 w-8 text-purple-600 dark:text-purple-300" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Access</h2>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Enter your password to access the admin panel
          </p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Password
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="block w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-700 dark:text-white"
              placeholder="Enter admin password"
              required
            />
            {error && (
              <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>
            )}
          </div>
          
          <Button
            type="submit"
            variant="primary"
            fullWidth
            isLoading={isLoading}
          >
            Login
          </Button>
          
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p>Caution: "Dont try to login if you are not a admin!!!!"</p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdminLogin;